package com.app.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;

public class SQLDatabaseConnection {

	public static void accessConnect(ArrayList<String> values) {

		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			Connection conn=DriverManager.getConnection("jdbc:ucanaccess://C://Users//divkhurana//Desktop//Quotes.accdb","",""); 
			Statement st=conn.createStatement();
			st.execute("create table quotes(quote_value nvarchar(40000))"); 
			for(String quotes_values:values) {
				
						st.execute("insert into quotes values('"+quotes_values+"')");	 
				
			}

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

	}
}