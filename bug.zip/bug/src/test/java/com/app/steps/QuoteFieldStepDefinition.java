package com.app.steps;




import org.openqa.selenium.By;
import org.testng.Assert;

import base.BaseTests;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class QuoteFieldStepDefinition extends BaseTests{
	
	@Given("^User launches the application$")
	public void user_launches_the_application() throws Throwable {
		launchApplication();	 
		driver.get(System.getProperty("app.url"));
        driver.manage().window().maximize();
	}

	@When("^User clicks on the Add New Quote button$")
	public void user_clicks_on_the_Add_New_Quote_button() throws Throwable {
	     driver.findElement(By.xpath("//button[@id='show-modal']")).click();;
	     
	   
	}
	@Then("^User enters the Author Name and the Quote Field with less than eight unique characters$")
	public void user_enters_the_Author_name_and_the_Quote_Field_with_less_than_eight_unique_characters() throws Throwable {
		 driver.findElement(By.xpath("//input[@id='autorInput']")).sendKeys(System.getProperty("author.name"));
		 driver.findElement(By.xpath("//input[@id='quoteInput']")).sendKeys(System.getProperty("quote.field"));
	}

	@Then("^User clicks on Save button$")
	public void user_clicks_on_Save_button() throws Throwable {
		driver.findElement(By.xpath("//button[contains(text(),'Save')]")).click();
	}

	@Then("^User validate whether the browser popup appears$")
	public void user_validate_whether_the_browser_popup_appears() throws Throwable {
		try {
			driver.switchTo().alert().getText();
		}
		catch(Exception e){
			System.out.println("The alert is not found");
		}
		closeBrowser();
	}
	@Then("^User enters the Author Name and the Quote Field with the word SKY in capital letter$")
	public void user_enters_the_Author_Name_and_the_Quote_Field_with_the_word_SKY_in_capital_letter() throws Throwable {
		driver.findElement(By.xpath("//input[@id='autorInput']")).sendKeys(System.getProperty("author.name1"));
		driver.findElement(By.xpath("//input[@id='quoteInput']")).sendKeys(System.getProperty("quote.field1"));
	}

	@Then("^User enters the Author Name and the Quote Field with the word sky in small letter$")
	public void user_enters_the_Author_Name_and_the_Quote_Field_with_the_word_sky_in_small_letter() throws Throwable {
		driver.findElement(By.xpath("//input[@id='autorInput']")).sendKeys(System.getProperty("author.name1"));
		driver.findElement(By.xpath("//input[@id='quoteInput']")).sendKeys(System.getProperty("quote.field2"));
	}

	@Then("^User enters SKY in search field$")
	public void user_enters_SKY_in_search_field() throws Throwable {
	   driver.findElement(By.xpath("//input[@id='searchBar']")).sendKeys(System.getProperty("quote.field3"));
	}

	@Then("^User validate the results displayed on the page for the Author Name$")
	public void user_validate_the_results_displayed_on_the_page_for_the_Author_Name() throws Throwable {
	   String value=driver.findElement(By.xpath("//li[contains(text(),'"+System.getProperty("author.name1")+"')]/p")).getText();
	   Assert.assertEquals(value, "2 Quotes", "SKY and sky are same as per the requirement, but it's not showing the correct results");
	}

	
}
