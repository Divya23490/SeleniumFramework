package com.app.steps;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.app.database.SQLDatabaseConnection;

import base.BaseTests;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class QuotesStoreStepDefinition extends BaseTests{
	public static String list;
	ArrayList<String> values=new ArrayList<>();
	@Given("^User navigates to the application$")
	public void user_navigates_to_the_application() throws Throwable {
		 launchApplication();
		 driver.get(System.getProperty("app2.url"));
		 driver.manage().window().maximize();
	}

	@Given("^User searches the quotes with Gideon value$")
	public void searches_quotes() throws Throwable {
		List<WebElement> quotes_data=driver.findElements(By.xpath("//div[contains(@class,'entry-content')]/p/strong[(text()='Gideon')]/.."));
		
		for(WebElement quotes_store:quotes_data) {
				list=quotes_store.getText().split(":")[1].replace("“","").replace("”", "");
				
				System.out.println(list);
				
				values.add(list);
		}		
		
		System.out.println(values.size());
	}

	@Then("^User stores the quotes in the database$")
	public void user_stores_the_quotes_in_the_database() throws Throwable {
		SQLDatabaseConnection.accessConnect(values);
		
	}@Then("^User closes the browser$")
	public void user_closes_the_browser() throws Throwable {
		closeBrowser();
	}

	
}
