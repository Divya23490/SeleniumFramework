package cucumber;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import base.BaseTests;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"pretty"},
        glue = {"cucumber.stepdefs"},
        features = {"src/test/resources/features"})

public class CucumberTestOptions {

    @BeforeClass
    public static void setUp() throws Throwable{
        BaseTests.launchApplication();
    }

    @AfterClass
    public static void tearDown(){
        BaseTests.closeBrowser();
    }
}