package base;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class BaseTests {

    protected static WebDriver driver;
    
    @BeforeClass
    public static void launchApplication() {
        Properties props = System.getProperties();
        try {
            props.load(
                    new FileInputStream(new File("resources/test.properties")));
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\divkhurana\\eclipse-workspace\\bug\\resources\\chromedriver.exe");
        driver = new ChromeDriver();
        

    }

    @AfterClass
    public static void closeBrowser() {
        driver.quit();
      
    }

}
